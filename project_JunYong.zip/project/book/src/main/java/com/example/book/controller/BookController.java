package com.example.book.controller;

import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.example.book.model.Book;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.bind.annotation.ModelAttribute;    
import org.springframework.web.bind.annotation.RequestMapping;    
import org.springframework.web.bind.annotation.RequestMethod;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import java.io.BufferedReader;
import java.io.InputStreamReader;


@Controller
public class BookController {
	
	@GetMapping("/index")
	public String getIndex(Model model) {
		String URL_BOOKS = "http://localhost:9001/api/v1/books";
		RestTemplate restTemplate = new RestTemplate();
		 
        // Send request with GET method and default Headers.
        Book[] list = restTemplate.getForObject(URL_BOOKS, Book[].class);
 
        if (list != null) {
        	for (int i=0;i<list.length;i++){
        		Book e=list[i];

                
            }
        	model.addAttribute("index",list);
        }
        
		return "index";
	}
	@RequestMapping("/edit/{id}")
	public String edit(@ModelAttribute Book book,Model model) {
		String URL_BOOKS = "http://localhost:9001/api/v1/books";
		RestTemplate restTemplate = new RestTemplate();
		 
        // Send request with GET method and default Headers.
		Book[] list = restTemplate.getForObject(URL_BOOKS, Book[].class);
 
        if (list != null) {
        	for (int i=0;i<list.length;i++){
        		Book e=list[i];
        		if (e.getId() ==book.getId()){
        			model.addAttribute("book",list[i]);
        		}
            }
        	
        }
		return "edit";
	}
	
	@RequestMapping(value="create", method=RequestMethod.POST)    
	public String save(@ModelAttribute Book book,Model model) throws IOException  
	{ 
		String inputJson="";
	
	        String putEndpoint = "http://localhost:9001/api/v1/books/"+book.getId();
	        CloseableHttpClient httpclient = HttpClients.createDefault();

	        HttpPut httpPut = new HttpPut(putEndpoint);
	        httpPut.setHeader("Accept", "application/json");
	        httpPut.setHeader("Content-type", "application/json");
	        
	        Book book2= new Book(book.getBookName(),book.getBorrowName(),book.getBorrowEmail(),book.getBorrowFlag());
	        		
	    		    
	         ObjectMapper mapper = new ObjectMapper();
	    		      //Converting the Object to JSONString
	    		    try{
	    		      inputJson = mapper.writeValueAsString(book2);
	    		    } catch (IOException e) {
	    	            e.printStackTrace();
	    	        }      
	        StringEntity stringEntity = new StringEntity(inputJson);
	        httpPut.setEntity(stringEntity);
	        HttpResponse response2 = httpclient.execute(httpPut);

	        BufferedReader br = new BufferedReader(new InputStreamReader((response2.getEntity().getContent())));

	        //Throw runtime exception if status code isn't 200 
	        if (response2.getStatusLine().getStatusCode() != 200) {
	            throw new RuntimeException("Failed : HTTP error code : " + response2.getStatusLine().getStatusCode());
	        }

	        //Create the StringBuffer object and store the response into it. 
	        StringBuffer result = new StringBuffer();
	        String line = "";
	        while ((line = br.readLine()) != null) {
	            System.out.println("Response : \n" + result.append(line));
	        }

	 return "redirect:/index";
	}
	
	@RequestMapping(value="add", method=RequestMethod.POST)    
	public String add(@ModelAttribute Book book,Model model) throws IOException  
	{ 
		String inputJson="";
		
		String putEndpoint = "http://localhost:9001/api/v1/books/";
        CloseableHttpClient httpclient = HttpClients.createDefault();

        HttpPost httpPost = new HttpPost(putEndpoint);
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Content-type", "application/json");
        
        Book book2= new Book(book.getBookName(),book.getBorrowName(),book.getBorrowEmail(),book.getBorrowFlag());
        		
    		    
         ObjectMapper mapper = new ObjectMapper();
    		      //Converting the Object to JSONString
    		    try{
    		      inputJson = mapper.writeValueAsString(book2);
    		    } catch (IOException e) {
    	            e.printStackTrace();
    	        }
    		      
        StringEntity stringEntity = new StringEntity(inputJson);
        httpPost.setEntity(stringEntity);

        HttpResponse response2 = httpclient.execute(httpPost);

        BufferedReader br = new BufferedReader(new InputStreamReader((response2.getEntity().getContent())));

        //Throw runtime exception if status code isn't 200 
        if (response2.getStatusLine().getStatusCode() != 200) {
            throw new RuntimeException("Failed : HTTP error code : " + response2.getStatusLine().getStatusCode());
        }

        //Create the StringBuffer object and store the response into it. 
        StringBuffer result = new StringBuffer();
        String line = "";
        while ((line = br.readLine()) != null) {
            System.out.println("Response : \n" + result.append(line));
        }
		return "redirect:/index";
		
	}
	@RequestMapping("/addInitial")
	public String addInitial(@ModelAttribute Book book, Model model) {
		model.addAttribute("bookName",null);
		model.addAttribute("borrowName",null);
		model.addAttribute("borrowEmail",null);
		model.addAttribute("borrowFlag",null);
        
		return "add";
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.GET)
	public String delete(@ModelAttribute Book book,Model model) {
		
		String URL_BOOKS = "http://localhost:9001/api/v1/book/"+book.getId();
		
		  Map < String, String > params = new HashMap < String, String > ();
	        RestTemplate restTemplate = new RestTemplate();
	        restTemplate.delete(URL_BOOKS, params);
	return "redirect:/index";
	}
	
	@GetMapping("/")
    public String root() {
		return "redirect:/index";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/access-denied")
    public String accessDenied() {
        return "/error/access-denied";
    }
    @GetMapping("/logout")
    public String logout() {
        return "logout";
    }

}
