package com.example.book.model;

public class Book {

	private Integer id;
	private String bookName;
    private String borrowName;
    private String borrowEmail;
    private String borrowFlag;
 
    public Book() {
 
    }
 
    public Book(String bookName, String borrowName, String borrowEmail, String borrowFlag) {
    	this.bookName = bookName;
        this.borrowName = borrowName;
        this.borrowEmail = borrowEmail;
        this.borrowFlag = borrowFlag;
    }

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getBorrowName() {
		return borrowName;
	}

	public void setBorrowName(String borrowName) {
		this.borrowName = borrowName;
	}

	public String getBorrowEmail() {
		return borrowEmail;
	}

	public void setBorrowEmail(String borrowEmail) {
		this.borrowEmail = borrowEmail;
	}

	public String getBorrowFlag() {
		return borrowFlag;
	}

	public void setBorrowFlag(String borrowFlag) {
		this.borrowFlag = borrowFlag;
	}
    
    
}
