package com.example.bookAPI.controller;

import com.example.bookAPI.model.Book;
import com.example.bookAPI.exception.ResourceNotFoundException;
import com.example.bookAPI.Repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class BookController {

  @Autowired
  private BookRepository bookRepository;

  /**
   * Get all books list.
   *
   * @return the list
   */
  @GetMapping("/books")
  public List<Book> getAllBooks() {
    return bookRepository.findAll();
  }

  /**
   * Gets books by id.
   *
   * @param bookId the book id
   * @return the books by id
   * @throws ResourceNotFoundException the resource not found exception
   */
  @GetMapping("/books/{id}")
  public ResponseEntity<Book> getBooksById(@PathVariable(value = "id") Long bookId)
      throws ResourceNotFoundException {
    Book book =
        bookRepository
            .findById(bookId)
            .orElseThrow(() -> new ResourceNotFoundException("Book not found on :: " + bookId));
    return ResponseEntity.ok().body(book);
  }

  /**
   * Create book book.
   *
   * @param book the book
   * @return the book
   */
  @PostMapping("/books")
  public Book createBook(@Valid @RequestBody Book book) {
    return bookRepository.save(book);
  }

  /**
   * Update book response entity.
   *
   * @param bookId the book id
   * @param bookDetails the book details
   * @return the response entity
   * @throws ResourceNotFoundException the resource not found exception
   */
  @PutMapping("/books/{id}")
  public ResponseEntity<Book> updateBook(
      @PathVariable(value = "id") Long bookId, @Valid @RequestBody Book bookDetails)
      throws ResourceNotFoundException {

    Book book =
        bookRepository
            .findById(bookId)
            .orElseThrow(() -> new ResourceNotFoundException("Book not found on :: " + bookId));
    
    book.setBookName(bookDetails.getBookName());
    book.setBorrowName(bookDetails.getBorrowName());
    book.setBorrowEmail(bookDetails.getBorrowEmail());
    book.setBorrowFlag(bookDetails.getBorrowFlag());
    
    final Book updatedBook = bookRepository.save(book);
    return ResponseEntity.ok(updatedBook);
  }

  /**
   * Delete book map.
   *
   * @param bookId the book id
   * @return the map
   * @throws Exception the exception
   */
  @DeleteMapping("/book/{id}")
  public Map<String, Boolean> deleteBook(@PathVariable(value = "id") Long bookId) throws Exception {
    Book book =
        bookRepository
            .findById(bookId)
            .orElseThrow(() -> new ResourceNotFoundException("Book not found on :: " + bookId));

    bookRepository.delete(book);
    Map<String, Boolean> response = new HashMap<>();
    response.put("deleted", Boolean.TRUE);
    return response;
  }
}
