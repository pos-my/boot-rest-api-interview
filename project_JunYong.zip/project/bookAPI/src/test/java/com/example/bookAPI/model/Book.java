package com.example.bookAPI.model;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

import java.util.Date;


@Entity
@Table(name = "book")
@EntityListeners(AuditingEntityListener.class)
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "book_name", nullable = false)
    private String bookName;

    @Column(name = "borrow_name", nullable = false)
    private String borrowName;

    @Column(name = "borrow_email", nullable = false)
    private String borrowEmail;
    
    @Column(name = "borrow_flag", nullable = false)
    private String borrowFlag;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_at", nullable = false)
    private Date createdAt;
    
  /**
   * Gets id.
   *
   * @return the id
   */
  public long getId() {
        return id;
    }

  /**
   * Sets id.
   *
   * @param id the id
   */
  public void setId(long id) {
        this.id = id;
    }

public String getBookName() {
	return bookName;
}

public void setBookName(String bookName) {
	this.bookName = bookName;
}

public String getBorrowName() {
	return borrowName;
}

public void setBorrowName(String borrowName) {
	this.borrowName = borrowName;
}

public String getBorrowEmail() {
	return borrowEmail;
}

public void setBorrowEmail(String borrowEmail) {
	this.borrowEmail = borrowEmail;
}

public String getBorrowFlag() {
	return borrowFlag;
}

public void setBorrowFlag(String borrowFlag) {
	this.borrowFlag = borrowFlag;
}

public Date getCreatedAt() {
	return createdAt;
}

public void setCreatedAt(Date createdAt) {
	this.createdAt = createdAt;
}

  


}
