package com.example.bookAPI;

import com.example.bookAPI.model.Book;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.boot.SpringApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class BookApiApplicationTests {

	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port;
	}

	@Test
	public void contextLoads() {
	}

	@Test
	public void testGetAllUsers() {
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/users",
				HttpMethod.GET, entity, String.class);

		Assert.assertNotNull(response.getBody());
	}

	@Test
	public void testGetUserById() {
		Book book = restTemplate.getForObject(getRootUrl() + "/book/1", Book.class);
		System.out.println(book.getBookName());
		Assert.assertNotNull(book);
	}

	@Test
	public void testCreateUser() {
		Book book = new Book();
		book.setBorrowEmail("admin@gmail.com");
		book.setBorrowFlag("Y");
		book.setBorrowName("admin");
		book.setBookName("book");

		ResponseEntity<Book> postResponse = restTemplate.postForEntity(getRootUrl() + "/book", book, Book.class);
		Assert.assertNotNull(postResponse);
		Assert.assertNotNull(postResponse.getBody());
	}

	@Test
	public void testUpdatePost() {
		int id = 1;
		Book book = restTemplate.getForObject(getRootUrl() + "/book/" + id, Book.class);
		book.setBookName("bookName");

		restTemplate.put(getRootUrl() + "/book/" + id, book);

		Book updatedBook = restTemplate.getForObject(getRootUrl() + "/book/" + id, Book.class);
		Assert.assertNotNull(updatedBook);
	}

	@Test
	public void testDeletePost() {
		int id = 2;
		Book book = restTemplate.getForObject(getRootUrl() + "/book/" + id, Book.class);
		Assert.assertNotNull(book);

		restTemplate.delete(getRootUrl() + "/book/" + id);

		try {
			book = restTemplate.getForObject(getRootUrl() + "/book/" + id, Book.class);
		} catch (final HttpClientErrorException e) {
			Assert.assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
		}
	}

}
